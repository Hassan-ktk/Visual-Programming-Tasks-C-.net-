﻿using EntityFrameworkMVC.Models;
using EntityFrameworkMVC.Models.AddModels;
using EntityFrameworkMVC.Models.Entities;
using Microsoft.AspNetCore.Mvc;

namespace EntityFrameworkMVC.Controllers
{
    public class UserController : Controller
    {
        private readonly EFMVC_DBContext _dbContext;

        public UserController(EFMVC_DBContext eFMVC_DBContext)
        {
            _dbContext = eFMVC_DBContext;
        }

        // GET: UserController
        public ActionResult Index()
        {
            var users = _dbContext.Users.ToList();
            return View(users);
        }

        // GET: UserController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: UserController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: UserController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(AddUser addUser)
        {
            try
            {
                User user = new User()
                {
                    Name = addUser.Name,
                    Email = addUser.Email
                };
                _dbContext.Users.Add(user);
                _dbContext.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UserController/Edit/5
        public ActionResult Edit(int id)
        {
            var user = _dbContext.Users.SingleOrDefault(u => u.Id == id);
            return View(user);
        }

        // POST: UserController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(User user)
        {
            try
            {
                var dbUser = _dbContext.Users.SingleOrDefault(u => u.Id == user.Id);
                if (dbUser == null)
                    return NotFound();

                dbUser.Name = user.Name;
                dbUser.Email = user.Email;

                _dbContext.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // POST: UserController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, User user)
        {
            try
            {
                var dbUser = _dbContext.Users.SingleOrDefault(u => u.Id == user.Id);
                if (dbUser == null)
                    return NotFound();

                _dbContext.Users.Remove(dbUser);
                _dbContext.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
