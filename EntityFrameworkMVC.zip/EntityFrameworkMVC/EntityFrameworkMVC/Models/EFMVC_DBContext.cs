﻿using EntityFrameworkMVC.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace EntityFrameworkMVC.Models
{
    public class EFMVC_DBContext : DbContext
    {
        public EFMVC_DBContext(DbContextOptions<EFMVC_DBContext> options) : base(options) 
        { }
        
        public DbSet<User> Users { get; set; } //konsa model use krna hai 

    }
    
}
