﻿namespace EntityFrameworkMVC.Models.AddModels
{
    public class AddUser
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
