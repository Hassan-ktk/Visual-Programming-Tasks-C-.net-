using Microsoft.EntityFrameworkCore;
using RestfullApisWithRepositoryDesignPattern1.Models.DataManager;
using RestfullApisWithRepositoryDesignPattern1.Models.Entities;
using RestfullApisWithRepositoryDesignPattern1.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//Register dbcontext
builder.Services.AddDbContext<AppDbContext>(
    option => option.UseSqlServer(builder.Configuration.GetConnectionString
    ("default"))
    );

//Register the data manager 
builder.Services.AddScoped<IDataRepository<User>, UserDataManager>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
