﻿namespace RestfullApisWithRepositoryDesignPattern1.Repositories
{
    public interface IDataRepository<TEntity>
    {
        IEnumerable<TEntity> GetAll();
        TEntity GetById(int id);
        void Add(TEntity entity);
        void Update(TEntity dbentity,TEntity entity);
        void Delete(TEntity entity);

    }
}
