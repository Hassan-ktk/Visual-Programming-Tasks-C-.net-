﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace RestfullApisWithRepositoryDesignPattern1.Models.Entities
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        { }

        public DbSet<User> Users { get; set; }

        //seeders
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Name = "Hassan",
                    Email = "Hassan123@gmail.com"
                },
                new User
                {
                    Id = 2,
                    Name = "Ali",
                    Email = "ali123@gmail.com"
                }

                );

        }

    }
}

