﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowFormAli
{
    public partial class Form1 : Form
    {
        string ConnectionString =
        "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=StudentInfo;Integrated Security=True;";

        public Form1()
        {
            InitializeComponent();
            LoadGridView();
        }

        
        private void LoadGridView()
        {
            SqlConnection Con = new SqlConnection(ConnectionString);
            Con.Open();

            string Qry = "SELECT * FROM Students";
            SqlDataAdapter SDA = new SqlDataAdapter(Qry, Con);
            DataTable Dt = new DataTable();
            SDA.Fill(Dt);

            Con.Close();
            DGVUsers.DataSource = Dt;
            CBBUsers.DataSource = Dt;
            CBBUsers.DisplayMember = "Name";  
            CBBUsers.ValueMember = "Id";

        }

       
        private void BtnSave_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(ConnectionString);
            Con.Open();

            string Qry =
            "INSERT INTO Students (Name, Email, Address, Department, Course, Blood, Hobbie) VALUES ('" +
            TxtName.Text + "','" +
            TxtEmail.Text + "','" +
            TxtAddress.Text + "','" +
            TxtDepartment.Text + "','" +
            TxtCourse.Text + "','" +
            TxtBlood.Text + "','" +
            TxtHobbie.Text + "')";

            SqlCommand Cmd = new SqlCommand(Qry, Con);

            if (Cmd.ExecuteNonQuery() > 0)
                MessageBox.Show("Data Saved Successfully!");
            else
                MessageBox.Show("Error Saving Data!");

            Con.Close();
            LoadGridView();
        }

       
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(ConnectionString);
            Con.Open();

            string Qry = "SELECT * FROM Students WHERE Id='" + CBBUsers.SelectedValue + "'";
            SqlDataAdapter SDA = new SqlDataAdapter(Qry, Con);
            DataTable Dt = new DataTable();
            SDA.Fill(Dt);

            Con.Close();

            if (Dt.Rows.Count > 0)
            {
                TxtName.Text = Dt.Rows[0]["Name"].ToString();
                TxtEmail.Text = Dt.Rows[0]["Email"].ToString();
                TxtAddress.Text = Dt.Rows[0]["Address"].ToString();
                TxtDepartment.Text = Dt.Rows[0]["Department"].ToString();
                TxtCourse.Text = Dt.Rows[0]["Course"].ToString();
                TxtBlood.Text = Dt.Rows[0]["Blood"].ToString();
                TxtHobbie.Text = Dt.Rows[0]["Hobbie"].ToString();
            }
            else
            {
                MessageBox.Show("Record Not Found!");
            }
        }

        
        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(ConnectionString);
            Con.Open();

            string Qry =
            "UPDATE Students SET " +
            "Name='" + TxtName.Text +
            "', Email='" + TxtEmail.Text +
            "', Address='" + TxtAddress.Text +
            "', Department='" + TxtDepartment.Text +
            "', Course='" + TxtCourse.Text +
            "', Blood='" + TxtBlood.Text +
            "', Hobbie='" + TxtHobbie.Text +
            "' WHERE Id='" + CBBUsers.Text + "'";

            SqlCommand Cmd = new SqlCommand(Qry, Con);

            if (Cmd.ExecuteNonQuery() > 0)
                MessageBox.Show("Data Updated Successfully!");
            else
                MessageBox.Show("Update Failed!");

            Con.Close();
            LoadGridView();
        }

       
        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(ConnectionString);
            Con.Open();

            string Qry = "DELETE FROM Students WHERE Id='" + CBBUsers.Text + "'";
            SqlCommand Cmd = new SqlCommand(Qry, Con);
            Cmd.ExecuteNonQuery();

            Con.Close();
            LoadGridView();
            MessageBox.Show("Data Deleted!");
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            
            TxtName.Clear();
            TxtEmail.Clear();
            TxtAddress.Clear();
            TxtDepartment.Clear();
            TxtCourse.Clear();
            TxtBlood.Clear();
            TxtHobbie.Clear();
        }
    }
}
